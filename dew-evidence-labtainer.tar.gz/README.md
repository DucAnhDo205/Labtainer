# DEW Evidence Video Labtainer

This directory contains a Labtainer lab for sealing a synthetic evidence video using a simplified DEW (Differential Energy Watermarking) method.

Lab name: `dew-evidence`

Containers:
- `demo`: student workstation. Creates a cover evidence video, embeds a seal message, extracts it, and submits artifacts.
- `tester`: independent test workstation. Receives the student's watermarked video, applies attacks, and validates extraction.

Required seal message: `DEW-EVIDENCE-2026`

Main parameters:
- Message length: 17 bytes
- Watermark bits: 136 bits
- Key: 7301
- PSNR target: at least 30 dB

The DEW idea used in this lab:
- Split the luminance channel of video frames into 8x8 DCT blocks.
- For each embedded bit, choose one block.
- Compare two mid-frequency coefficient groups.
- To embed `1`, force energy(group A) greater than energy(group B) by a margin.
- To embed `0`, force energy(group B) greater than energy(group A) by a margin.
- Extraction is blind: it only compares the two group energies.

References used for the design:
- G. C. Langelaar and R. L. Lagendijk, "Optimal differential energy watermarking of DCT encoded images and video", IEEE Transactions on Image Processing, 2001.
- Labtainer Lab Designer User Guide, Naval Postgraduate School.

## Install Into Labtainers

On the Labtainer designer VM:

```bash
cd "$LABTAINER_DIR/labs"
mkdir dew-evidence
cd dew-evidence
new_lab_setup.py
new_lab_setup.py -a tester
```

Then copy the contents of `dew-evidence/` from this starter into:

```bash
$LABTAINER_DIR/labs/dew-evidence/
```

Overwrite the generated template files when prompted, then test:

```bash
cd "$LABTAINER_DIR/scripts/labtainer-student"
rebuild dew-evidence
```

Stop and collect artifacts:

```bash
stoplab
```

## Student Workflow

In `demo`:

```bash
python make_cover.py
python dew_embed.py --in cover.dwv --out watermarked.dwv --message "DEW-EVIDENCE-2026" --key 7301
python dew_extract.py --in watermarked.dwv --length 17 --key 7301
python quality.py --ref cover.dwv --test watermarked.dwv
python submit_dew.py
```

Transfer to `tester`:

```bash
scp watermarked.dwv ubuntu@tester:/home/ubuntu/
```

In `tester`:

```bash
./run_tests.sh watermarked.dwv 17 7301
```

Expected result: extraction succeeds on the original watermarked video and may survive mild re-encoding.
