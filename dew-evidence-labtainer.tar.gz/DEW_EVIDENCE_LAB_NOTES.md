Lab `dew-evidence` is a Labtainer exercise about sealing a synthetic evidence video with Differential Energy Watermarking (DEW).

Scenario:
- The `demo` container acts as the analyst workstation.
- The `tester` container acts as an independent verification workstation.
- Students embed the evidence seal `DEW-EVIDENCE-2026` into `cover.dwv`, verify blind extraction, measure PSNR, and copy the watermarked video to `tester`.

Main parameters:
- Message length: 17 bytes
- Watermark bits: 136 bits
- Key: 7301
- PSNR requirement: >= 30 dB
- Educational video format: `.dwv` JSON grayscale frames

Important commands on `demo`:

```bash
python make_cover.py
python dew_embed.py --in cover.dwv --out watermarked.dwv --message "DEW-EVIDENCE-2026" --key 7301
python dew_extract.py --in watermarked.dwv --length 17 --key 7301
python quality.py --ref cover.dwv --test watermarked.dwv
python submit_dew.py
scp watermarked.dwv ubuntu@tester:/home/ubuntu/
```

Important command on `tester`:

```bash
./run_tests.sh watermarked.dwv 17 7301
```

Host checkwork:

```bash
checkwork dew-evidence
```

Expected grading markers:
- `COVER_OK=Y`
- `EMBED_BITS=136`
- `EXTRACT_OK=Y`
- `PSNR_OK=Y`
- `VERIFY_ORIGINAL=Y`
- `VERIFY_ATTACKED=Y`
