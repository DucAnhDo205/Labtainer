Lab `dew-audit` is a Labtainer exercise about marking a synthetic audit video with Differential Energy Watermarking (DEW).

Scenario:
- The `audit` container acts as the student workstation.
- The `verifier` container acts as an independent verification workstation.
- Students embed the audit trace `DEW-AUDIT-TRACE26` into `cover.dwv`, verify blind extraction, measure PSNR, and copy the watermarked video to `verifier`.

Main parameters:
- Message length: 17 bytes
- Watermark bits: 136 bits
- Key: 9107
- PSNR requirement: >= 30 dB
- Educational video format: `.dwv` JSON grayscale frames

Important commands on `audit`:

```bash
python make_cover.py
python dew_embed.py --in cover.dwv --out watermarked.dwv --message "DEW-AUDIT-TRACE26" --key 9107
python dew_extract.py --in watermarked.dwv --length 17 --key 9107
python quality.py --ref cover.dwv --test watermarked.dwv
python submit_dew.py
scp watermarked.dwv ubuntu@verifier:/home/ubuntu/
```

Important command on `verifier`:

```bash
./run_tests.sh watermarked.dwv 17 9107
```

Host checkwork:

```bash
checkwork dew-audit
```

Expected grading markers:
- `COVER_OK=Y`
- `EMBED_BITS=136`
- `EXTRACT_OK=Y`
- `PSNR_OK=Y`
- `VERIFY_ORIGINAL=Y`
- `VERIFY_ATTACKED=Y`
