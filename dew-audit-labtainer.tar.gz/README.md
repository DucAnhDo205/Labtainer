# DEW Audit Video Labtainer

This directory contains a Labtainer lab for adding an audit trace to a synthetic grayscale video using simplified DEW (Differential Energy Watermarking).

Lab name: `dew-audit`

Containers:
- `audit`: student workstation. Creates a cover audit video, embeds a trace message, extracts it, and submits artifacts.
- `verifier`: independent verification workstation. Receives the student's watermarked video, applies a compression-like attack, and validates extraction.

Required trace message: `DEW-AUDIT-TRACE26`

Main parameters:
- Message length: 17 bytes
- Watermark bits: 136 bits
- Key: 9107
- PSNR target: at least 30 dB

The DEW idea used in this lab:
- Split the luminance channel of video frames into 8x8 DCT blocks.
- For each embedded bit, choose one block.
- Compare two mid-frequency coefficient groups.
- To embed `1`, force energy(group A) greater than energy(group B).
- To embed `0`, force energy(group B) greater than energy(group A).
- Extraction is blind: it only compares the two group energies.

## Student Workflow

In `audit`:

```bash
python make_cover.py
python dew_embed.py --in cover.dwv --out watermarked.dwv --message "DEW-AUDIT-TRACE26" --key 9107
python dew_extract.py --in watermarked.dwv --length 17 --key 9107
python quality.py --ref cover.dwv --test watermarked.dwv
python submit_dew.py
```

Transfer to `verifier`:

```bash
scp watermarked.dwv ubuntu@verifier:/home/ubuntu/
```

In `verifier`:

```bash
./run_tests.sh watermarked.dwv 17 9107
```

Expected result: extraction succeeds on the original watermarked video and on the mild compression-like attacked version.
